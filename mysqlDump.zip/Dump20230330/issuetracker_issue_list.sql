-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: issuetracker
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issue_list`
--

DROP TABLE IF EXISTS `issue_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT NULL,
  `tracker` enum('bug','feature') DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `status` enum('new','closed') NOT NULL DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `issue_list_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects_list` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_list`
--

LOCK TABLES `issue_list` WRITE;
/*!40000 ALTER TABLE `issue_list` DISABLE KEYS */;
INSERT INTO `issue_list` VALUES (1,2,'bug','hello world','closed','2023-03-30 01:49:15'),(2,3,'bug','need to fix this soon','closed','2023-03-30 01:56:56'),(3,1,'bug','sertstrdx','closed','2023-03-30 02:01:35'),(4,3,'feature','this is a feature','closed','2023-03-30 02:03:45'),(5,6,'feature','this is a bug','closed','2023-03-30 02:05:22'),(6,4,'bug','read','closed','2023-03-30 02:09:15'),(7,6,'feature','hwoo','closed','2023-03-30 02:11:38'),(8,6,'bug','this is','closed','2023-03-30 02:12:27'),(9,11,'bug','this is a new issue','closed','2023-03-30 06:53:40'),(10,6,'bug','this is it','closed','2023-03-30 07:50:32'),(11,2,'feature','aaaaa','closed','2023-03-30 07:53:49'),(12,2,'bug','this is it','closed','2023-03-30 07:56:19'),(13,3,'feature','this is a new feature','closed','2023-03-30 08:33:10'),(14,3,'bug','This is an old bug','closed','2023-03-30 08:33:31'),(15,3,'feature','this is old feature','closed','2023-03-30 08:34:12'),(16,3,'feature','this is old feature','closed','2023-03-30 08:34:50'),(17,3,'feature','hello feature','closed','2023-03-30 08:41:13'),(18,3,'bug','Bug free','closed','2023-03-30 08:41:56'),(19,3,'bug','Hello featurebug','new','2023-03-30 08:42:23'),(20,13,'bug','This is a new bug','closed','2023-03-30 09:31:20'),(21,13,'feature','This is a new feature','closed','2023-03-30 09:31:32'),(22,13,'feature','this is a new feature','closed','2023-03-30 09:31:54'),(23,13,'bug','This is a new issue','closed','2023-03-30 09:35:50'),(24,12,'bug','This is a new bug','closed','2023-03-30 09:49:12'),(25,12,'feature','hello','closed','2023-03-30 09:59:11'),(26,14,'feature','Welcome','closed','2023-03-30 10:14:40');
/*!40000 ALTER TABLE `issue_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-30 15:59:19
